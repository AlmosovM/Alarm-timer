var al = {}
var redefine = false;

al.init = function () {
    if (!redefine) {
        al.sound = document.getElementById("alarm-sound");
        al.time = document.getElementById('timeNow');
        al.showAlarm = document.getElementById('showalarm');
        al.response = document.getElementById('responsemsg');
        al.alarmNow = document.getElementById('alarmNow');

        al.set = document.getElementById("setAlarm");
        al.set.addEventListener("click", al.setAlrm);
        al.rset = document.getElementById("reset");
        al.rset.addEventListener("click", al.reset);

        al.snooze = document.getElementById("snooze");
        al.snooze.addEventListener("click", al.snz);
        al.stop = document.getElementById("stopAlarm");
        al.stop.addEventListener("click", al.stp);

        redefine = true;
    }
    al.hour = document.getElementById("hour");
    al.minute = document.getElementById("minute");
    al.currentTimezone = 'local';
    al.timeZoneval = 0;
    al.clearreponse();

    al.reg = /^\d+$/;
    al.alarm = null;
    al.alarmStatus = false;
    al.alarmconfigured = false;
    setInterval(al.currentTime, 1000);
    al.clearalarmstatus();
}

al.currentTime = function () {
    var now = new Date();
    var chr = now.getHours() + al.timeZoneval;
    console.log("chr is " + chr)
    if (chr <= 0) {
        chr += 24;
    }
    if (chr >= 24) {
        chr -= 24;
    }
    var chr = al.addZero(chr);
    var cmin = al.addZero(now.getMinutes());
    var csec = al.addZero(now.getSeconds());
    al.time.innerHTML = chr + ':' + cmin + ':' + csec;
    var timeIs = chr + cmin;

    if (al.alarm != null) {
        if (timeIs == al.alarm) {
            al.sound.play();
            al.show(true);
        }
    }
}

al.addZero = function (num) {

    num = parseInt(num);
    if (num < 10) { num = "0" + num; }
    else { num = num.toString(); }
    return num;
}

al.setAlrm = function () {
    if (al.alarmconfigured === false) {
        al.hour = al.hour.value;
        al.minute = al.minute.value;

        if (al.reg.test(al.hour) && al.reg.test(al.minute)) {
            al.hour = al.addZero(al.hour);
            al.minute = al.addZero(al.minute);

            if ((al.hour >= 0 && al.hour < 24 && al.hour != "0") && (al.minute >= 0 && al.minute < 60 && al.minute != "0")) {

                al.alarm = al.hour + al.minute;
                al.printAlarm();
                al.alarmconfigured = true;
            }
            else {
                al.printInvalid();
                setTimeout(al.tryagain, 2000);
            }
        }
        else {
            al.printInvalid();
            setTimeout(al.tryagain, 2000);
        }
    }
    else {
        al.response.innerHTML = "Before seting new alarm reset current alarm";
        setTimeout(al.clearreponse, 1000);
    }
}

al.snz = function () {
    if (al.alarm != null) {
        if (!al.sound.paused) {
            al.sound.pause();
            al.minute = al.addZero(parseInt(al.minute) + 1);
            if (al.minute > 59) {
                al.minute -= 60;
                al.hour += 1;
            }
            al.alarm = al.hour + al.minute;
            al.printAlarmSnoozed();
            al.show(false);
            setInterval(al.currentTime, 1000);
        }
        else {

            al.printNoalrmtosnooze();
        }
    }
    else {

        al.printNoalrmtosnooze();
    }

}

al.stp = function () {
    if (al.alarm != null) {
        al.alarm = null;
        if (!al.sound.paused) {
            al.sound.pause();
        }
        al.show(false);
        al.printAlarmStopped();
    }
    else {
        al.printNo();
    }
    setTimeout(al.init, 1000)

}

al.reset = function () {
    al.sound.pause();

    if (al.alarm != null) {
        al.printAlarmReset();
        al.alarm = null;
        al.show(false);
        al.alarmconfigured === false;

    }
    else {
        al.printNo();
    }

    setTimeout(al.init, 1000)

}

al.show = function (state) {
    if (state === true) {
        al.alarmNow.style.display = 'block';
        al.alarmNow.classList.toggle('alarmblink');
    }
    else {
        al.alarmNow.style.display = 'none';

    }
}

al.printAlarm = function () {
    al.showAlarm.innerHTML = "Alarm set to: " + al.hour + ":" + al.minute;
    document.getElementById("hour").value = null;
    document.getElementById("minute").value = null;
}
al.printAlarmReset = function () {
    al.showAlarm.innerHTML = "Alarm Resetted";
}
al.printAlarmSnoozed = function () {
    al.showAlarm.innerHTML = "Alarm snoozed to: " + al.hour + ":" + al.minute;
}
al.printAlarmStopped = function () {
    al.showAlarm.innerHTML = "Alarm Stopped";

}
al.printNoalrmtosnooze = function () {
    al.showAlarm.innerHTML = "No Alarm to Snooze";
    al.showAlarm.style.color = "red";
    setTimeout(al.clearalarmstatus, 1000);
}
al.printInvalid = function () {
    al.response.innerHTML = "You enter invalid time for Alarm";
}
al.clearalarmstatus = function () {
    al.showAlarm.innerHTML = 'Currently no alarm is configured';
    al.showAlarm.style.color = "black";
}
al.clearreponse = function () {
    al.response.innerHTML = "";
}
al.printNo = function () {
    al.showAlarm.innerHTML = "No Alarm to Stop or Reset";
    al.showAlarm.style.color = "red";
    setTimeout(al.clearalarmstatus, 1000)
}
al.tryagain = function () {
    document.getElementById("hour").value = null;
    document.getElementById("minute").value = null;
    al.alarmconfigured === false;
    al.init();
}

al.setTimezone = function (e) {
    var timeZoneid = e.id;
    if (al.currentTimezone1 != timeZoneid) {
        al.currentTimezone1 = timeZoneid;

        switch (timeZoneid) {
            case "us":
                al.timeZoneval = 10;
                break;
            case "France":
                al.timeZoneval = 5;
                break;
            case "England":
                al.timeZoneval = 4;
                break;
            case "Thai":
                al.timeZoneval = -14;
                break;
            default:
                al.timeZoneval = 0;
        }
    }

}


al.init();